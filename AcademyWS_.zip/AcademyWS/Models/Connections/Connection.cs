﻿using AcademyWs.Models.Entities;
using System.Data.Entity;

namespace AcademyWs.Models.Connections
{
    public class ConnBD : DbContext
    {
        public DbSet<Aluno> alunos { get; set; }
        public DbSet<Avaliacao> Avaliacoes { get; set; }
        public DbSet<Curso> cursos { get; set; }
        public DbSet<Matricula> matriculas { get; set; }
        public DbSet<Nota> notas { get; set; }
    }
}