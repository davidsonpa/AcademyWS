﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcademyWs.Models.Entities
{
    [Table("Matricula")]
    public class Matricula
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int idMatricula { get; set; }
        public ICollection<Aluno> idAluno { get; set; }
        public ICollection<Curso> idCurso { get; set; }
        public DateTime Data { get; set; }

    }
}