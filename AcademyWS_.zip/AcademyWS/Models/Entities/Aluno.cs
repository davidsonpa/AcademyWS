﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcademyWs.Models.Entities
{
    [Table("Aluno")]
    public class Aluno
    {
        //[Key]
        //[Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int idAluno { get; set; }

        //[Key]
        //[Column(Order = 2)]
        [StringLength(11)]
        [Required(ErrorMessage = "Informe o CPF do Aluno!")]
        [MaxLength(11, ErrorMessage = "O CPF deverá ser informado com 11 dígitos, sem formatação!")]
        public string cpf { get; set; }
        [StringLength(50)]
        public string nome { get; set; }
        [StringLength(50)]
        public string endereco { get; set; }
        [StringLength(50)]
        public string municipio { get; set; }
        [StringLength(2)]
        public string estado { get; set; }
        [StringLength(14)]
        public string telefone { get; set; }
        [Key]
        [Column(Order = 1)]
        [StringLength(100)]
        public string email {get; set;}
        [StringLength(30)]
        public string senha {get; set;}
    }
}

