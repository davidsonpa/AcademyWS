﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcademyWs.Models.Entities
{
    [Table("Avaliacao")]
    public class Avaliacao
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int idAvaliacao { get; set; }
        public string descricao { get; set; }
        public ICollection<Curso> idCurso { get; set; }
        public DateTime data { get; set; }
 
    }
}