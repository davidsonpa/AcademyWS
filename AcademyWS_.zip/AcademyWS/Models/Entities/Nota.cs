﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcademyWs.Models.Entities
{
    [Table("Nota")]
    public class Nota
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int idNota { get; set; }
        public ICollection<Avaliacao> idAvaliacao { get; set; }
        public ICollection<Aluno> idAluno { get; set; }
        public decimal nota { get; set; }

   
    }
}