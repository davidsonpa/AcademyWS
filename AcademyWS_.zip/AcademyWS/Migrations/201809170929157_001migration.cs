namespace AcademyWS.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _001migration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Aluno",
                c => new
                    {
                        cpf = c.String(nullable: false, maxLength: 11),
                        idAluno = c.Int(nullable: false, identity: true),
                        nome = c.String(maxLength: 50),
                        endereco = c.String(maxLength: 50),
                        municipio = c.String(maxLength: 50),
                        estado = c.String(maxLength: 2),
                        telefone = c.String(maxLength: 14),
                        email = c.String(maxLength: 100),
                        senha = c.String(maxLength: 30),
                        Matricula_idMatricula = c.Int(),
                        Nota_idNota = c.Int(),
                    })
                .PrimaryKey(t => t.cpf)
                .ForeignKey("dbo.Matricula", t => t.Matricula_idMatricula)
                .ForeignKey("dbo.Nota", t => t.Nota_idNota)
                .Index(t => t.Matricula_idMatricula)
                .Index(t => t.Nota_idNota);
            
            CreateTable(
                "dbo.Avaliacao",
                c => new
                    {
                        idAvaliacao = c.Int(nullable: false, identity: true),
                        descricao = c.String(),
                        data = c.DateTime(nullable: false),
                        Nota_idNota = c.Int(),
                    })
                .PrimaryKey(t => t.idAvaliacao)
                .ForeignKey("dbo.Nota", t => t.Nota_idNota)
                .Index(t => t.Nota_idNota);
            
            CreateTable(
                "dbo.Curso",
                c => new
                    {
                        idcurso = c.Int(nullable: false, identity: true),
                        descricao = c.String(),
                        ano_mes = c.String(),
                        Avaliacao_idAvaliacao = c.Int(),
                        Matricula_idMatricula = c.Int(),
                    })
                .PrimaryKey(t => t.idcurso)
                .ForeignKey("dbo.Avaliacao", t => t.Avaliacao_idAvaliacao)
                .ForeignKey("dbo.Matricula", t => t.Matricula_idMatricula)
                .Index(t => t.Avaliacao_idAvaliacao)
                .Index(t => t.Matricula_idMatricula);
            
            CreateTable(
                "dbo.Matricula",
                c => new
                    {
                        idMatricula = c.Int(nullable: false, identity: true),
                        Data = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.idMatricula);
            
            CreateTable(
                "dbo.Nota",
                c => new
                    {
                        idNota = c.Int(nullable: false, identity: true),
                        nota = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.idNota);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Avaliacao", "Nota_idNota", "dbo.Nota");
            DropForeignKey("dbo.Aluno", "Nota_idNota", "dbo.Nota");
            DropForeignKey("dbo.Curso", "Matricula_idMatricula", "dbo.Matricula");
            DropForeignKey("dbo.Aluno", "Matricula_idMatricula", "dbo.Matricula");
            DropForeignKey("dbo.Curso", "Avaliacao_idAvaliacao", "dbo.Avaliacao");
            DropIndex("dbo.Curso", new[] { "Matricula_idMatricula" });
            DropIndex("dbo.Curso", new[] { "Avaliacao_idAvaliacao" });
            DropIndex("dbo.Avaliacao", new[] { "Nota_idNota" });
            DropIndex("dbo.Aluno", new[] { "Nota_idNota" });
            DropIndex("dbo.Aluno", new[] { "Matricula_idMatricula" });
            DropTable("dbo.Nota");
            DropTable("dbo.Matricula");
            DropTable("dbo.Curso");
            DropTable("dbo.Avaliacao");
            DropTable("dbo.Aluno");
        }
    }
}
