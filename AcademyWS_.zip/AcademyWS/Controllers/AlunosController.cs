﻿using AcademyWs.Models.Connections;
using AcademyWs.Models.Entities;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using System.Net;
using System;

namespace AcademyWs.Controllers
{
    public class AlunosController : ApiController
    {
        ConnBD db = new ConnBD();

        public IHttpActionResult PostAluno(Aluno aluno)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.alunos.Add(aluno);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { idAluno = aluno.idAluno }, aluno);
        }


        [HttpGet]
        public IHttpActionResult AutenticarAluno(String email, String senha)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var aluno = db.alunos.Find(email);

            if ((email != aluno.email) || (senha != aluno.senha))
                return BadRequest("O E-mail e/ou Senha informados não são validos!");

            return Ok();
        }


        public IHttpActionResult PutAluno(int idAluno, Aluno aluno)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (idAluno != aluno.idAluno)
                return BadRequest("O código informado não é valido!");

            if (db.alunos.Count(i => i.idAluno == aluno.idAluno) == 0)
                return NotFound();

            db.Entry(aluno).State = EntityState.Modified;
            db.SaveChanges();


            return StatusCode(HttpStatusCode.NoContent);
        }

        public IHttpActionResult DeleteAluno(int idAluno, Aluno aluno)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (idAluno != aluno.idAluno)
                return BadRequest("O código informado não é valido!");

            if (db.alunos.Count(i => i.idAluno == aluno.idAluno) == 0)
                return NotFound();

            //db.alunos.Remove(aluno);
            db.Entry(aluno).State = EntityState.Deleted;
            db.SaveChanges();

            return StatusCode(HttpStatusCode.NoContent);
        }




    }
}
